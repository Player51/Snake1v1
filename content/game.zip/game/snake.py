from constants import *
import numpy as np
import pygame

class Snake:
    def __init__(self, x, y, color, head_color, curr_dir):
        self.x = x
        self.y = y
        self.head = Block(self.x, self.y)
        self.snake_elements = [
            self.head,
            Block(self.head.x - BLOCK_SIZE, self.head.y),
            Block(self.head.x - 2 * BLOCK_SIZE, self.head.y)
        ]
        self.current_direction = curr_dir
        self.color = color
        self.head_color = head_color

    def update(self, action):
        directions = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
        idx = directions.index(self.current_direction)

        # relative movement from snake's head, not from player's screen.
        # use modulo to cycle inside the one-hot movement list
        if np.array_equal(action, [1, 0, 0]):
            new_dir = directions[idx]
        elif np.array_equal(action, [0, 1, 0]):
            new_dir = directions[(idx + 1) % 4]
        else:
            new_dir = directions[(idx - 1) % 4]

        self.current_direction = new_dir

        new_x = self.head.x
        new_y = self.head.y
        if self.current_direction == Direction.RIGHT:
            new_x += BLOCK_SIZE
        elif self.current_direction == Direction.LEFT:
            new_x -= BLOCK_SIZE
        elif self.current_direction == Direction.DOWN:
            new_y += BLOCK_SIZE
        elif self.current_direction == Direction.UP:
            new_y -= BLOCK_SIZE

        self.head = Block(new_x, new_y)
        self.snake_elements.insert(0, self.head)

    def move(self, new_direction):
        if new_direction != self.current_direction or new_direction != None:
            self.current_direction = new_direction

        new_x = self.head.x
        new_y = self.head.y

        if self.current_direction == Direction.RIGHT:
            new_x += BLOCK_SIZE
        elif self.current_direction == Direction.LEFT:
            new_x -= BLOCK_SIZE
        elif self.current_direction == Direction.DOWN:
            new_y += BLOCK_SIZE
        elif self.current_direction == Direction.UP:
            new_y -= BLOCK_SIZE

        self.head = Block(new_x, new_y)
        self.snake_elements.insert(0, self.head)

    def draw(self, win):
        pygame.draw.rect(win, self.head_color, pygame.Rect(
            self.snake_elements[0].x, self.snake_elements[0].y, BLOCK_SIZE, BLOCK_SIZE))
        for block in self.snake_elements[1:]:
            pygame.draw.rect(win, self.color, pygame.Rect(
                block.x, block.y, BLOCK_SIZE, BLOCK_SIZE))

    def is_collided(self, block=None, include_self=True):
        if block is None:
            block = self.head
        if include_self and block in self.snake_elements[1:]:
            return True
        if block.x >= WIN_WIDTH or block.x < 0 or block.y >= WIN_HEIGHT or block.y < 0:
            return True
        return False
    
    def get_distance_from_apple(self, apple):
        return np.sqrt((self.head.x - apple.x)**2 + (self.head.y - apple.y)**2)