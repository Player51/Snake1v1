from constants import *
import random
import pygame
from collections import namedtuple

Block = namedtuple("Block", "x, y")

class Apple:
    def __init__(self, snakes, color):
        self.snakes = snakes
        self.color = color
        self.change_pos()

    def spawn_apple(self):
        while True:
            x = random.randint(0, (WIN_WIDTH - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            y = random.randint(0, (WIN_HEIGHT - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            block = Block(x, y)
            if all(block not in snake.snake_elements for snake in self.snakes):
                return x, y

    def change_pos(self):
        self.x, self.y = self.spawn_apple()

    def draw(self, win):
        pygame.draw.rect(win, self.color, pygame.Rect(self.x, self.y, BLOCK_SIZE, BLOCK_SIZE))