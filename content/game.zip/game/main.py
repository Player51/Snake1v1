from game_classes import SnakeGame1v1_Training, SnakeGame1v1_HumanPlay, MessageBox, Direction
from agent import Agent, TestAgent
import time

MODEL_PATH = "models/soft200_expandings/model600.weights.h5"

if __name__ == '__main__':
    mb = MessageBox("Snake1v1", "Choose precisely.")
    user_choice = mb.show()

    if user_choice == "training":
        """ Training process """
        BATCH_SIZE = 64
        env = SnakeGame1v1_Training()
        agent = Agent()


        ''' For training pre-trained model: use the next two lines '''
        #agent.model.load_weights(MODEL_PATH)  for training pre-trained model
        #agent.epsilon *= 0.5                  for some epxloration


        env.reset()
        state = env._get_state()

        while True:
            next_state, action, reward, done, info = agent.play_one_step(env, state)
            state = next_state

            if done:
                agent.n_games += 1
                env.reset()
                print(f"episode: {agent.n_games}")

            if len(agent.memory) > BATCH_SIZE:
                agent.training_step(BATCH_SIZE)

            if agent.n_games % 50 == 0 and agent.n_games >= 100:  # after 50 episodes when training from existing model
                agent.model.save_weights(f"models/model{agent.n_games}.weights.h5")

    elif user_choice == "human_play":
        env = SnakeGame1v1_HumanPlay()
        agent = TestAgent(MODEL_PATH)
        env.reset()
        env.waiting = False
        state = env._get_state()

        while True:
            action = agent.get_action(state)
            next_state, reward, done, info = env.play_step(action)
            state = next_state

            if done:
                env.reset()
                state = env._get_state()
                env.snake2.move(Direction.UP)
                env.draw()
                time.sleep(2)
                env.waiting = False
        
