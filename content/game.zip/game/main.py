from snake1v1_classes import SnakeGame1v1_Training, SnakeGame1v1_HumanPlay
from constants import Direction
from message_box import MessageBox
from agent import Agent, TestAgent
import pygame
import time
import os


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'models\model600.weights.h5')

def run_training():
    pygame.init()
    BATCH_SIZE = 64
    env = SnakeGame1v1_Training()
    agent = Agent()

    env.reset()
    state = env._get_state()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return  pygame.quit()
        next_state, action, reward, done, info = agent.play_one_step(env, state)
        state = next_state

        if done:
            agent.n_games += 1
            env.reset()
            print(f"episode: {agent.n_games}")

        if len(agent.memory) > BATCH_SIZE:
            agent.training_step(BATCH_SIZE)

        if agent.n_games % 50 == 0 and agent.n_games >= 100:
            agent.model.save_weights(f"models/model{agent.n_games}.weights.h5")

def run_human_play():
    pygame.init()
    env = SnakeGame1v1_HumanPlay()
    agent = TestAgent(MODEL_PATH)
    env.reset()
    env.waiting = False
    state = env._get_state()

    while True:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
            return pygame.quit()

        action = agent.get_action(state)
        next_state, reward, done, info = env.play_step(action)
        state = next_state

        if done:
            env.reset()
            state = env._get_state()
            env.snake2.move(Direction.UP)
            env.draw()
            time.sleep(2)
            env.waiting = False

if __name__ == '__main__':
    while True:
        mb = MessageBox("Snake1v1", "Choose precisely.")
        user_choice = mb.show()

        if user_choice == "training":
            run_training()
        elif user_choice == "human_play":
            run_human_play()
        else:
            break
