import tkinter as tk
from tkinter import ttk 

class MessageBox:
    def __init__(self, title, message, button1_text="Training", button2_text="Human play"):
        self.title = title
        self.message = message
        self.button1_text = button1_text
        self.button2_text = button2_text
        self.result = None
        self.window = tk.Tk()
        self.window.title(self.title)
        self.window.resizable(False, False)  # Prevent resizing
        self._style_window()
        self._create_widgets()
        self._center_window()

    def _style_window(self):
        """Applies a basic style to the window."""
        self.bg_color = "#fffcf2"
        self.font_family = "Times New Roman"
        self.window.configure(bg=self.bg_color)

        style = ttk.Style(self.window)
        style.theme_use("default")

        style.configure("TFrame", background=self.bg_color)
        style.configure("TLabel", background=self.bg_color, font=(self.font_family, 14))

        # Custom button style
        style.configure("Custom.TButton",
                        font=(self.font_family, 12, "bold"),
                        padding=10,
                        background="#f5b971",
                        foreground="#2e2e2e",
                        borderwidth=0,
                        focusthickness=3,
                        focuscolor='none')

        style.map("Custom.TButton",
                background=[("active", "#f8a94b")],
                foreground=[("disabled", "#a0a0a0")])

    def _center_window(self):
        """Centers the window on the screen."""
        self.window.update_idletasks()  # Ensure accurate winfo_reqwidth/height
        screen_width = self.window.winfo_screenwidth()
        screen_height = self.window.winfo_screenheight()
        window_width = self.window.winfo_reqwidth()
        window_height = self.window.winfo_reqheight()
        position_top = int(screen_height / 2 - window_height / 2)
        position_right = int(screen_width / 2 - window_width / 2)
        self.window.geometry(f"+{position_right}+{position_top}")

    def _button1_click(self):
        self.result = "training"
        self.window.destroy()

    def _button2_click(self):
        self.result = "human_play"
        self.window.destroy()

    def _create_widgets(self):
        message_label = ttk.Label(self.window, text=self.message, padding=(20, 15), wraplength=300, justify="center")
        message_label.pack(pady=(15, 10))

        button_frame = ttk.Frame(self.window)
        button_frame.pack(pady=(5, 15))

        button1 = ttk.Button(button_frame, text=self.button1_text, command=self._button1_click,
                            style="Custom.TButton", width=12)
        button1.pack(side=tk.LEFT, padx=10)

        button2 = ttk.Button(button_frame, text=self.button2_text, command=self._button2_click,
                            style="Custom.TButton", width=12)
        button2.pack(side=tk.LEFT, padx=10)

    def show(self):
        self.window.mainloop()
        return self.result