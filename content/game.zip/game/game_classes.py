import pygame
from enum import Enum
from collections import namedtuple
import random
import numpy as np

import tkinter as tk
from tkinter import ttk 

pygame.init()

WIN_WIDTH = 640
WIN_HEIGHT = 480
BLOCK_SIZE = 20

GAME_SPEED = 12 # 60 for training, 10 to 15 for human play

BLACK = (0, 0, 0)
RED = (255, 0, 0)

BACKGROUND = (255, 252, 242)
SNAKE_BODY = (37, 36, 34)
AI_SNAKE_HEAD = (245, 203, 92)
PLAYER_SNAKE_HEAD = (255, 0, 110)
APPLE = (235, 94, 40)

class Direction(Enum):
    RIGHT = 1
    LEFT = 2
    UP = 3
    DOWN = 4

Block = namedtuple("Block", "x, y") # ~mini-class 

class Snake:
    def __init__(self, x, y, color, head_color, curr_dir):
        self.x = x
        self.y = y
        self.head = Block(self.x, self.y)
        self.snake_elements = [
            self.head,
            Block(self.head.x - BLOCK_SIZE, self.head.y),
            Block(self.head.x - 2 * BLOCK_SIZE, self.head.y)
        ]
        self.current_direction = curr_dir
        self.color = color
        self.head_color = head_color

    def update(self, action):
        directions = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
        idx = directions.index(self.current_direction)

        if np.array_equal(action, [1, 0, 0]):
            new_dir = directions[idx]
        elif np.array_equal(action, [0, 1, 0]):
            new_dir = directions[(idx + 1) % 4]
        else:
            new_dir = directions[(idx - 1) % 4]

        self.current_direction = new_dir

        new_x = self.head.x
        new_y = self.head.y
        if self.current_direction == Direction.RIGHT:
            new_x += BLOCK_SIZE
        elif self.current_direction == Direction.LEFT:
            new_x -= BLOCK_SIZE
        elif self.current_direction == Direction.DOWN:
            new_y += BLOCK_SIZE
        elif self.current_direction == Direction.UP:
            new_y -= BLOCK_SIZE

        self.head = Block(new_x, new_y)
        self.snake_elements.insert(0, self.head)

    def move(self, new_direction):
        if new_direction != self.current_direction or new_direction != None:
            self.current_direction = new_direction

        new_x = self.head.x
        new_y = self.head.y

        if self.current_direction == Direction.RIGHT:
            new_x += BLOCK_SIZE
        elif self.current_direction == Direction.LEFT:
            new_x -= BLOCK_SIZE
        elif self.current_direction == Direction.DOWN:
            new_y += BLOCK_SIZE
        elif self.current_direction == Direction.UP:
            new_y -= BLOCK_SIZE

        self.head = Block(new_x, new_y)
        self.snake_elements.insert(0, self.head)

    def draw(self, win):
        pygame.draw.rect(win, self.head_color, pygame.Rect(
            self.snake_elements[0].x, self.snake_elements[0].y, BLOCK_SIZE, BLOCK_SIZE))
        for block in self.snake_elements[1:]:
            pygame.draw.rect(win, self.color, pygame.Rect(
                block.x, block.y, BLOCK_SIZE, BLOCK_SIZE))

    def is_collided(self, block=None, include_self=True):
        if block is None:
            block = self.head
        if include_self and block in self.snake_elements[1:]:
            return True
        if block.x >= WIN_WIDTH or block.x < 0 or block.y >= WIN_HEIGHT or block.y < 0:
            return True
        return False
    
    def get_distance_from_apple(self, apple):
        return np.sqrt((self.head.x - apple.x)**2 + (self.head.y - apple.y)**2)
    
class Apple:
    def __init__(self, snakes, color):
        self.snakes = snakes
        self.color = color
        self.change_pos()

    def spawn_apple(self):
        while True:
            x = random.randint(0, (WIN_WIDTH - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            y = random.randint(0, (WIN_HEIGHT - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            block = Block(x, y)
            if all(block not in snake.snake_elements for snake in self.snakes):
                return x, y

    def change_pos(self):
        self.x, self.y = self.spawn_apple()

    def draw(self, win):
        pygame.draw.rect(win, self.color, pygame.Rect(self.x, self.y, BLOCK_SIZE, BLOCK_SIZE))

class SnakeGame1v1_Base:
    def __init__(self):
        self.display = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        pygame.display.set_caption(self.get_caption())
        self.clock = pygame.time.Clock()
        self.reset()
        
        self.last_winner = "Let's see..."
        self.target_score = 15

        self.snake1_wins = 0
        self.snake2_wins = 0
        self.waiting = False

    def reset(self):
        self.snake1 = Snake(100, WIN_HEIGHT // 2, color=self.snake1_body(), head_color=self.snake1_head(), curr_dir=Direction.RIGHT)
        self.snake2 = Snake(WIN_WIDTH - 100, WIN_HEIGHT // 2, color=self.snake2_body(), head_color=self.snake2_head(), curr_dir=Direction.UP)
        self.apple = Apple([self.snake1, self.snake2], self.apple_color())
        self.frame = 0
        self.score1 = 0
        self.score2 = 0
        self.game_over = False
        self.waiting = True

    def play_step(self, action):
        self.frame += 1
        reward = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            self.handle_input(event)

        old_distance = self.snake1.get_distance_from_apple(self.apple)

        self.snake1.update(action)
        self.move_snake2()

        if self.snake2.is_collided() or self.snake2.head in self.snake1.snake_elements:
            self.game_over = True
            reward += 50
            self.snake1_wins += 1
            self.last_winner = "Ai :( I'm sure it was a mistake.."
            return self._get_state(), reward, self.game_over, self.score1
        
        if self.snake1.is_collided() or self.snake1.head in self.snake2.snake_elements:
            self.game_over = True
            reward -= 100
            self.snake2_wins += 1
            self.last_winner = "Human :) stupid Ai collided you, or himself"
            return self._get_state(), reward, self.game_over, self.score1

        if self.snake1.head.x == self.apple.x and self.snake1.head.y == self.apple.y:
            self.score1 += 1
            reward += 10
            self.apple.change_pos()
        else:
            self.snake1.snake_elements.pop()

        if self.snake2.head.x == self.apple.x and self.snake2.head.y == self.apple.y:
            self.score2 += 1
            self.apple.change_pos()
        else:
            self.snake2.snake_elements.pop()

        if self.score1 == self.target_score:
            self.game_over = True
            reward += 100 # experimental ...
            self.snake1_wins += 1
            self.last_winner = "Ai :( stole every apple"
            return self._get_state(), reward, self.game_over, self.score1
        
        if self.score2 == self.target_score:
            self.game_over = True
            reward -= 100 # experimental ...
            self.snake2_wins += 1
            self.last_winner = "Human :) won target apples"
            return self._get_state(), reward, self.game_over, self.score1

        new_distance = self.snake1.get_distance_from_apple(self.apple)
        reward += 5 if new_distance < old_distance else -5

        self.draw()
        self.clock.tick(GAME_SPEED)

        return self._get_state(), reward, self.game_over, self.score1

    def _get_state(self):
        head = self.snake1.snake_elements[0]
        block_left = Block(head.x - BLOCK_SIZE, head.y)
        block_right = Block(head.x + BLOCK_SIZE, head.y)
        block_up = Block(head.x, head.y - BLOCK_SIZE)
        block_down = Block(head.x, head.y + BLOCK_SIZE)

        dir_left = self.snake1.current_direction == Direction.LEFT
        dir_right = self.snake1.current_direction == Direction.RIGHT
        dir_up = self.snake1.current_direction == Direction.UP
        dir_down = self.snake1.current_direction == Direction.DOWN

        state = [
            (dir_left and self.snake1.is_collided(block_left)) or
            (dir_right and self.snake1.is_collided(block_right)) or
            (dir_up and self.snake1.is_collided(block_up)) or
            (dir_down and self.snake1.is_collided(block_down)),

            (dir_left and self.snake1.is_collided(block_up)) or
            (dir_right and self.snake1.is_collided(block_down)) or
            (dir_up and self.snake1.is_collided(block_right)) or
            (dir_down and self.snake1.is_collided(block_left)),

            (dir_left and self.snake1.is_collided(block_down)) or
            (dir_right and self.snake1.is_collided(block_up)) or
            (dir_up and self.snake1.is_collided(block_left)) or
            (dir_down and self.snake1.is_collided(block_right)),

            dir_left,
            dir_right,
            dir_up,
            dir_down,

            self.apple.x < head.x,
            self.apple.x > head.x,
            self.apple.y < head.y,
            self.apple.y > head.y,

            self.snake2.head.x < head.x,
            self.snake2.head.x > head.x,
            self.snake2.head.y < head.y,
            self.snake2.head.y > head.y,

            abs(self.snake2.head.x - head.x) <= BLOCK_SIZE and abs(self.snake2.head.y - head.y) <= BLOCK_SIZE,

            self.snake2.current_direction == Direction.LEFT,
            self.snake2.current_direction == Direction.RIGHT,
            self.snake2.current_direction == Direction.UP,
            self.snake2.current_direction == Direction.DOWN
        ]

        return np.array(state, dtype=int)

    # functions to override
    def handle_input(self, event): raise NotImplementedError 
    def move_snake2(self): raise NotImplementedError
    def draw(self): raise NotImplementedError
    def get_caption(self): raise NotImplementedError
    def snake1_body(self): raise NotImplementedError
    def snake1_head(self): raise NotImplementedError
    def snake2_body(self): raise NotImplementedError
    def snake2_head(self): raise NotImplementedError
    def apple_color(self): raise NotImplementedError

class SnakeGame1v1_Training(SnakeGame1v1_Base):
    def move_snake2(self):
        self.snake2.update(self.get_bot_move(self.snake2))
        #self.snake2.update(self.get_safe_random_move(self.snake2)) 

    def draw(self):
        self.display.fill(BLACK)
        self.snake1.draw(self.display)
        self.snake2.draw(self.display)
        self.apple.draw(self.display)
        font = pygame.font.SysFont("Times New Roman", 20)
        score_text1 = font.render(f"Ai Agent: {self.score1}", True, (0, 255, 0))
        score_text2 = font.render(f"Programmed Bot: {self.score2}", True, (52, 55, 235))
        self.display.blit(score_text1, [10, 10])
        self.display.blit(score_text2, [10, 30])
        pygame.display.flip()

    def get_caption(self): return "Snake1v1 Training"
    def snake1_body(self): return (0, 100, 0)
    def snake1_head(self): return (0, 255, 0)
    def snake2_body(self): return (52, 55, 235)
    def snake2_head(self): return (52, 140, 235)
    def apple_color(self): return RED

    def get_bot_move(self, snake):
        # Make the bot go in a clockwise square pattern.
        # It will try to complete a square of roughly 10 blocks size.
        target_x = 5 * BLOCK_SIZE
        target_y = 5 * BLOCK_SIZE
        square_size = 10 * BLOCK_SIZE

        head = snake.head
        current_direction = snake.current_direction
        directions = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
        current_dir_index = directions.index(current_direction)

        # Define the corners of the target square
        corners = [Block(target_x, target_y),
                Block(target_x + square_size, target_y),
                Block(target_x + square_size, target_y + square_size),
                Block(target_x, target_y + square_size)]

        # Determine which side of the square the head is currently on (or close to)
        if abs(head.x - corners[0].x) < BLOCK_SIZE and abs(head.y - corners[0].y) < BLOCK_SIZE and current_direction == Direction.LEFT:
            new_direction = Direction.UP
        elif abs(head.x - corners[1].x) < BLOCK_SIZE and abs(head.y - corners[1].y) < BLOCK_SIZE and current_direction == Direction.UP:
            new_direction = Direction.RIGHT
        elif abs(head.x - corners[2].x) < BLOCK_SIZE and abs(head.y - corners[2].y) < BLOCK_SIZE and current_direction == Direction.RIGHT:
            new_direction = Direction.DOWN
        elif abs(head.x - corners[3].x) < BLOCK_SIZE and abs(head.y - corners[3].y) < BLOCK_SIZE and current_direction == Direction.DOWN:
            new_direction = Direction.LEFT
        else:
            new_direction = current_direction
            if current_direction == Direction.RIGHT and head.x < corners[1].x:
                pass
            elif current_direction == Direction.DOWN and head.y < corners[2].y:
                pass
            elif current_direction == Direction.LEFT and head.x > corners[3].x:
                pass
            elif current_direction == Direction.UP and head.y > corners[0].y:
                pass
            else:
                # If not moving towards the next corner, try to turn clockwise
                next_dir_index = (current_dir_index + 1) % 4
                new_direction = directions[next_dir_index]

        # Convert the new direction to an action array [straight, right, left]
        if new_direction == current_direction:
            return np.array([1, 0, 0], dtype=int)
        elif directions[(current_dir_index + 1) % 4] == new_direction:
            return np.array([0, 1, 0], dtype=int)
        else:
            return np.array([0, 0, 1], dtype=int)
        
    def get_safe_random_move(self, snake):
        """
        Returns a random valid move for the snake that does not lead to immediate death.
        """
        head = snake.head
        current_direction = snake.current_direction
        possible_actions = [
            np.array([1, 0, 0]),  # Straight
            np.array([0, 1, 0]),  # Right turn
            np.array([0, 0, 1])   # Left turn
        ]
        valid_actions = []
        directions = [Direction.RIGHT, Direction.DOWN, Direction.LEFT, Direction.UP]
        current_dir_index = directions.index(current_direction)

        for action in possible_actions:
            new_direction = current_direction
            if np.array_equal(action, [0, 1, 0]):  # Right turn
                new_direction = directions[(current_dir_index + 1) % 4]
            elif np.array_equal(action, [0, 0, 1]):  # Left turn
                new_direction = directions[(current_dir_index - 1) % 4]

            next_head = head
            if new_direction == Direction.RIGHT:
                next_head = Block(head.x + BLOCK_SIZE, head.y)
            elif new_direction == Direction.LEFT:
                next_head = Block(head.x - BLOCK_SIZE, head.y)
            elif new_direction == Direction.UP:
                next_head = Block(head.x, head.y - BLOCK_SIZE)
            elif new_direction == Direction.DOWN:
                next_head = Block(head.x, head.y + BLOCK_SIZE)

            if not snake.is_collided(next_head):
                valid_actions.append(action)

        if valid_actions:
            return random.choice(valid_actions)
        else:
            # If no safe move is found (which shouldn't happen in most cases
            # unless the snake is completely surrounded), return the current
            # direction to at least keep moving.
            return np.array([1, 0, 0])

    def handle_input(self, event):
        return event # training no human input, but must implement function
      
class SnakeGame1v1_HumanPlay(SnakeGame1v1_Base):
    def handle_input(self, event):
        if event.type == pygame.KEYDOWN:
            if (event.key == pygame.K_w or event.key == pygame.K_UP) and self.snake2.current_direction != Direction.DOWN:
                self.snake2.current_direction = Direction.UP
            elif (event.key == pygame.K_s or event.key == pygame.K_DOWN) and self.snake2.current_direction != Direction.UP:
                self.snake2.current_direction = Direction.DOWN
            elif (event.key == pygame.K_a or event.key == pygame.K_LEFT) and self.snake2.current_direction != Direction.RIGHT:
                self.snake2.current_direction = Direction.LEFT
            elif (event.key == pygame.K_d or event.key == pygame.K_RIGHT) and self.snake2.current_direction != Direction.LEFT:
                self.snake2.current_direction = Direction.RIGHT

    def move_snake2(self):
        self.snake2.move(self.snake2.current_direction)

    def draw(self):
        font = pygame.font.SysFont("Times New Roman", 20)
        self.display.fill(BACKGROUND)
        self.snake1.draw(self.display)
        self.snake2.draw(self.display)
        self.apple.draw(self.display)
        if self.waiting:
            s = pygame.Surface((WIN_WIDTH,WIN_HEIGHT))  # the size of your rect
            s.set_alpha(128)                # alpha level
            s.fill((255,255,255))           # this fills the entire surface
            self.display.blit(s, (0,0))    # (0,0) are the top-left coordinates
            font2 = pygame.font.SysFont("Times New Roman", 40)
            waiting_text = font2.render("Be Ready!", True, BLACK)
            self.display.blit(waiting_text, [WIN_WIDTH / 2 - 80, WIN_HEIGHT / 2 - 40])

        
        score_text1 = font.render(f"Ai Agent: {self.score1}", True, AI_SNAKE_HEAD)
        score_text2 = font.render(f"Human Player: {self.score2}", True, PLAYER_SNAKE_HEAD)
        winner_text = font.render(f"Last Winner: {self.last_winner}, ({self.snake1_wins} - {self.snake2_wins})", True, PLAYER_SNAKE_HEAD)
        self.display.blit(score_text1, [10, 10])
        self.display.blit(score_text2, [10, 30])
        self.display.blit(winner_text, [10, WIN_HEIGHT-30])
        pygame.display.flip()

    def get_caption(self): return "Snake1v1 Human play"
    def snake1_body(self): return SNAKE_BODY
    def snake1_head(self): return AI_SNAKE_HEAD
    def snake2_body(self): return SNAKE_BODY
    def snake2_head(self): return PLAYER_SNAKE_HEAD
    def apple_color(self): return APPLE

class MessageBox:
    def __init__(self, title, message, button1_text="Training", button2_text="Human play"):
        self.title = title
        self.message = message
        self.button1_text = button1_text
        self.button2_text = button2_text
        self.result = None
        self.window = tk.Tk()
        self.window.title(self.title)
        self.window.resizable(False, False)  # Prevent resizing
        self._style_window()
        self._create_widgets()
        self._center_window()

    def _style_window(self):
        """Applies a basic style to the window."""
        self.bg_color = "#fffcf2"
        self.font_family = "Times New Roman"
        self.window.configure(bg=self.bg_color)

        style = ttk.Style(self.window)
        style.theme_use("default")

        style.configure("TFrame", background=self.bg_color)
        style.configure("TLabel", background=self.bg_color, font=(self.font_family, 14))

        # Custom button style
        style.configure("Custom.TButton",
                        font=(self.font_family, 12, "bold"),
                        padding=10,
                        background="#f5b971",
                        foreground="#2e2e2e",
                        borderwidth=0,
                        focusthickness=3,
                        focuscolor='none')

        style.map("Custom.TButton",
                background=[("active", "#f8a94b")],
                foreground=[("disabled", "#a0a0a0")])

    def _center_window(self):
        """Centers the window on the screen."""
        self.window.update_idletasks()  # Ensure accurate winfo_reqwidth/height
        screen_width = self.window.winfo_screenwidth()
        screen_height = self.window.winfo_screenheight()
        window_width = self.window.winfo_reqwidth()
        window_height = self.window.winfo_reqheight()
        position_top = int(screen_height / 2 - window_height / 2)
        position_right = int(screen_width / 2 - window_width / 2)
        self.window.geometry(f"+{position_right}+{position_top}")

    def _button1_click(self):
        self.result = "training"
        self.window.destroy()

    def _button2_click(self):
        self.result = "human_play"
        self.window.destroy()

    def _create_widgets(self):
        message_label = ttk.Label(self.window, text=self.message, padding=(20, 15), wraplength=300, justify="center")
        message_label.pack(pady=(15, 10))

        button_frame = ttk.Frame(self.window)
        button_frame.pack(pady=(5, 15))

        button1 = ttk.Button(button_frame, text=self.button1_text, command=self._button1_click,
                            style="Custom.TButton", width=12)
        button1.pack(side=tk.LEFT, padx=10)

        button2 = ttk.Button(button_frame, text=self.button2_text, command=self._button2_click,
                            style="Custom.TButton", width=12)
        button2.pack(side=tk.LEFT, padx=10)

    def show(self):
        self.window.mainloop()
        return self.result
    
# hello