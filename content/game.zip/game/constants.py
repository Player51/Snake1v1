from enum import Enum

WIN_WIDTH = 640
WIN_HEIGHT = 480
BLOCK_SIZE = 20

GAME_SPEED = 12 # 60 for training, 10 to 15 for human play

BLACK = (0, 0, 0)
RED = (255, 0, 0)

BACKGROUND = (255, 252, 242)
SNAKE_BODY = (37, 36, 34)
AI_SNAKE_HEAD = (245, 203, 92)
PLAYER_SNAKE_HEAD = (255, 0, 110)
APPLE = (235, 94, 40)

class Direction(Enum):
    RIGHT = 1
    LEFT = 2
    UP = 3
    DOWN = 4